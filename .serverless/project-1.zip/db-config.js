module.exports = {
    host            : "database-1.csiaifsgxmlh.us-east-1.rds.amazonaws.com",
    user            : "admin",
    password        : "Jaxon2018",
    database        : "database-1"
};

console.log(process.env);