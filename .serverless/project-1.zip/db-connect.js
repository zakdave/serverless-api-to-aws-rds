const dbConfig = require('./db-config');
const mysql = require('serverless-mysql')({
    config: dbConfig
});

module.exports = mysql;
