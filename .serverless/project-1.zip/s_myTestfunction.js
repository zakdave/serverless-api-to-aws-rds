
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zakdave',
  applicationName: 'serverless-api',
  appUid: 'FNV7v5qvZ0L3h67CWp',
  orgUid: '171ca972-f8fe-4ed9-be7b-de674fa7b562',
  deploymentUid: '2305b5c7-6a2e-4c8e-8063-0fac38eeb029',
  serviceName: 'project-1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'project-1-dev-myTestfunction', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.myTestFunction, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}