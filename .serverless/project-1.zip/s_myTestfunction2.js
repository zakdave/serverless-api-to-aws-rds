
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zakdave',
  applicationName: 'serverless-api',
  appUid: 'FNV7v5qvZ0L3h67CWp',
  orgUid: '171ca972-f8fe-4ed9-be7b-de674fa7b562',
  deploymentUid: 'd7e67457-d380-4384-a1fe-fdb72189984e',
  serviceName: 'project-1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'project-1-dev-myTestfunction2', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.myTestFunction2, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}